delete from pedido;

insert into pedido (id, data_criacao, valor) values (1, utc_timestamp, 308.90);
insert into pedido (id, data_criacao, valor) values (2, utc_timestamp, 79);
insert into pedido (id, data_criacao, valor) values (3, '2019-10-30 21:55:44', 120);
insert into pedido (id, data_criacao, valor) values (4, '2019-11-02 21:10:32', 179.40);
insert into pedido (id, data_criacao, valor) values (5, '2019-09-16 02:20:10', 97.20);
insert into pedido (id, data_criacao, valor) values (6, '2019-07-23 04:30:56', 56.40);
insert into pedido (id, data_criacao, valor) values (7, '2019-10-28 12:11:12', 82.30);
insert into pedido (id, data_criacao, valor) values (8, '2018-12-16 19:57:58', 580.99);
insert into pedido (id, data_criacao, valor) values (9, '2018-10-13 16:30:00', 96.50);
insert into pedido (id, data_criacao, valor) values (10, '2018-06-05 23:37:17', 23.45);
