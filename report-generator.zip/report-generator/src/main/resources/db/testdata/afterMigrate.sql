delete from pedido;

insert into pedido (id, data_criacao, valor) values (1, utc_timestamp, 308.90);
insert into pedido (id, data_criacao, valor) values (2, utc_timestamp, 79);
insert into pedido (id, data_criacao, valor) values (3, date('2019-10-30'), 120);
insert into pedido (id, data_criacao, valor) values (4, date('2019-11-02'), 179.40);
insert into pedido (id, data_criacao, valor) values (5, date('2019-09-16'), 97.20);
insert into pedido (id, data_criacao, valor) values (6, date('2019-07-23'), 56.40);
insert into pedido (id, data_criacao, valor) values (7, date('2019-10-28'), 82.30);
insert into pedido (id, data_criacao, valor) values (8, date('2018-12-16'), 580.99);
insert into pedido (id, data_criacao, valor) values (9, date('2018-10-13'), 96.50);
insert into pedido (id, data_criacao, valor) values (10, date('2018-06-05'), 23.45);
