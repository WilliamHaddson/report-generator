package com.report.generator.domain.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.report.generator.domain.exception.PedidoNaoEncontradoException;
import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.repository.PedidoRepository;

@Service
public class PedidoService {

	@Autowired
	private PedidoRepository repository;
	
	public List<Pedido> listar() {
		return repository.findAll();
	}

	@Transactional
	public Pedido emitir(Pedido pedido) {
		return repository.save(pedido);
	}

	public Pedido buscarOuFalhar(Long pedidoId) {
		return repository.findById(pedidoId)
			.orElseThrow(() -> new PedidoNaoEncontradoException(pedidoId));
	}
	
	public List<Pedido> buscarPorDataCriacao(Date data) {
		return repository.findByDataCriacaoAfter(data);
	}

}
