package com.report.generator.infrastructure.service;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Service;

import com.report.generator.domain.exception.ReportException;
import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.service.PedidoReportService;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class ExcelPedidoReportService implements PedidoReportService {

	@Override
	public byte[] emitirRelatorioPedido(List<Pedido> pedidos) {
		try {
			var inputStream = this.getClass().getResourceAsStream("/relatorios/pedido-report.jasper");
			
			var parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
			
			var dataSource = new JRBeanCollectionDataSource(pedidos);
			
			var jasperPrint = JasperFillManager.fillReport(inputStream, parametros, dataSource);
			
			return JasperExportManager.exportReportToPdf(jasperPrint);
			
		} catch (Exception e) {
			throw new ReportException("Não foi possível emitir relatório de pedidos", e);
		}
	}

}
