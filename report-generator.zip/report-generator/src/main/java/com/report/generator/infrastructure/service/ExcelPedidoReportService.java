package com.report.generator.infrastructure.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.report.generator.domain.exception.ReportException;
import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.model.dto.ExcelReturn;
import com.report.generator.domain.service.PedidoReportService;
import com.report.generator.domain.service.PedidoService;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;

@Service
public class ExcelPedidoReportService implements PedidoReportService {

	@Autowired
	private PedidoService service;

	@SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	@Override
	public ExcelReturn emitirRelatorioPedido(List<Pedido> pedidos) {
		try {
			var inputStream = this.getClass().getResourceAsStream("/relatorios/pedido-report.jasper");
			
			var parametros = new HashMap<String, Object>();
			parametros.put("REPORT_LOCALE", new Locale("pt", "BR"));
			
			var dataSource = new JRBeanCollectionDataSource(pedidos);
			
			ExcelReturn excel = new ExcelReturn();
			excel.setFilename(UUID.randomUUID().toString() + "_pedidos.xlsx");
			excel.setPath(System.getenv("HOMEPATH") + "\\Downloads\\");
			
			String filename = excel.getPath() + excel.getFilename();
			
			
			var out = new FileOutputStream(new File(filename), false);
		
			var jasperPrint = JasperFillManager.fillReport(inputStream, parametros, dataSource);
			var exporter = new JRXlsxExporter();
			var xlsReport = new ByteArrayOutputStream();
			
			exporter.setParameter(JRXlsExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JRXlsExporterParameter.OUTPUT_STREAM, xlsReport);
            exporter.setParameter(JRXlsExporterParameter.IS_ONE_PAGE_PER_SHEET, new Boolean(false));
            exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_COLUMNS, new Boolean(true));
            exporter.setParameter(JRXlsExporterParameter.IS_REMOVE_EMPTY_SPACE_BETWEEN_ROWS, new Boolean(true)); 
			exporter.exportReport();
			
			byte bytes[] = xlsReport.toByteArray();
			xlsReport.close();
			
			out.write(bytes);
			out.flush();
			out.close();
			
			return excel;
			
		} catch (Exception e) {
			throw new ReportException("Não foi possível emitir relatório de pedidos", e);
		}
	}

}
