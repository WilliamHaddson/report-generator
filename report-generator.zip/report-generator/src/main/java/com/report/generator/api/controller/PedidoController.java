package com.report.generator.api.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.report.generator.domain.exception.NegocioException;
import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.service.PedidoReportService;
import com.report.generator.domain.service.PedidoService;

@RestController
@RequestMapping(path = "/pedidos")
public class PedidoController {

	@Autowired
	private PedidoService service;
	
	@Autowired
	private PedidoReportService reportService;
	
	@GetMapping("/relatorio")
	public ModelAndView novo() {
		ModelAndView mv = new ModelAndView("RelatorioPedidos");
		
		return mv;
	}
	
	@GetMapping(path = "/relatorio/excel", produces = "application/xls")
	public ResponseEntity<byte[]> gerarExcelRelatorio(@RequestParam(required = false) String data) {
		List<Pedido> pedidos;
		if(!data.isBlank()) {
			pedidos = service.buscarPorDataCriacao(getData(data));
		} else {
			pedidos = service.listar();
		}
		
		byte[] pdfToExcel = reportService.emitirRelatorioPedido(pedidos);
		String filename = UUID.randomUUID().toString() + "-pedidos.xls";
		
		var headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
		
		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType("application/xls"))
				.headers(headers)
				.body(pdfToExcel);
	}

	private Date getData(String stringData) {
		try {
			SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
			formater.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date data = formater.parse(stringData);
			
			return data;
		} catch (ParseException e) {
			throw new NegocioException("Por algum motivo, sua data não foi aceita. Por favor, verifique a formatação!");
		}
	}
	
}
