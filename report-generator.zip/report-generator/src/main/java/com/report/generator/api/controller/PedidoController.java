package com.report.generator.api.controller;

import java.net.URI;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.model.dto.ExcelReturn;
import com.report.generator.domain.model.dto.Links;
import com.report.generator.domain.service.PedidoReportService;
import com.report.generator.domain.service.PedidoService;

@RestController
@RequestMapping(path = "/pedidos")
public class PedidoController {

	@Autowired
	private PedidoService service;
	
	@Autowired
	private PedidoReportService reportService;
	
	@GetMapping
	public List<Pedido> listar() {
		return service.listar();
	}

	@GetMapping("/{pedidoId}")
	public Pedido buscar(@PathVariable Long pedidoId) {
		return service.buscarOuFalhar(pedidoId);
	}
	
	@GetMapping("/relatorio")
	public ResponseEntity<Links> buscarRelatorio(@RequestParam String data, HttpServletResponse response) {
		Links links = new Links();
		
		URI uriJson = ServletUriComponentsBuilder.fromCurrentRequestUri()
				.path("/json").queryParam("data", data).build().toUri();
		URI uriExcel = ServletUriComponentsBuilder.fromCurrentRequestUri()
				.path("/excel").queryParam("data", data).build().toUri();
		
		links.setUriJson(uriJson);
		links.setUriExcel(uriExcel);
		
		return ResponseEntity.status(HttpStatus.OK).body(links);
	}
	
	@GetMapping("/relatorio/json")
	public List<Pedido> gerarJsonRelatorio(@RequestParam Date data) {
		return service.buscarPorDataCriacao(data);
	}
	
	@GetMapping(path = "/relatorio/excel")
	public ResponseEntity<ExcelReturn> gerarExcelRelatorio(@RequestParam Date data) {
		List<Pedido> pedidos = service.buscarPorDataCriacao(data);
		ExcelReturn excel = reportService.emitirRelatorioPedido(pedidos);
		
		var headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+excel.getFilename());
		
		return ResponseEntity.ok()
				.headers(headers)
				.body(excel);
	}
	
}
