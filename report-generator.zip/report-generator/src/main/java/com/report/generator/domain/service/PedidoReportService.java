package com.report.generator.domain.service;

import java.util.List;

import com.report.generator.domain.model.Pedido;
import com.report.generator.domain.model.dto.ExcelReturn;

public interface PedidoReportService {
	
	ExcelReturn emitirRelatorioPedido(List<Pedido> pedidos);

}
