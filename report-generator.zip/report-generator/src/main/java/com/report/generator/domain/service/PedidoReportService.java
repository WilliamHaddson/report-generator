package com.report.generator.domain.service;

import java.util.List;

import com.report.generator.domain.model.Pedido;

public interface PedidoReportService {
	
	byte[] emitirRelatorioPedido(List<Pedido> pedidos);

}
