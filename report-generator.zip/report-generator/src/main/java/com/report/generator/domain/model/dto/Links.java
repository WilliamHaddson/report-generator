package com.report.generator.domain.model.dto;

import java.net.URI;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Links {
	
	
	private URI uriJson;
	private URI uriExcel;

}
