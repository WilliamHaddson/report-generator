package com.report.generator.domain.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.report.generator.domain.model.Pedido;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long>,
		JpaSpecificationExecutor<Pedido> {

	Optional<Pedido> findById(Long id);

	List<Pedido> findAll();
	
	@Query("from Pedido p where p.dataCriacao >= :data")
	List<Pedido> findByDataCriacaoAfter(@Param(value = "data") Date data);
	
}
