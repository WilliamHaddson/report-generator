package com.report.generator.domain.model.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExcelReturn {
	
	private String path;
	private String filename;

}
